rm -rf ./nuget

rm -rf ~/.nuget/packages/identityserver4